"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/pretendard@1.3.9";
exports.ids = ["vendor-chunks/pretendard@1.3.9"];
exports.modules = {

/***/ "(rsc)/./node_modules/.pnpm/pretendard@1.3.9/node_modules/pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css":
/*!*****************************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/pretendard@1.3.9/node_modules/pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css ***!
  \*****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (\"80e2dfd22f6f\");\nif (false) {}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvLnBucG0vcHJldGVuZGFyZEAxLjMuOS9ub2RlX21vZHVsZXMvcHJldGVuZGFyZC9kaXN0L3dlYi92YXJpYWJsZS9wcmV0ZW5kYXJkdmFyaWFibGUtZHluYW1pYy1zdWJzZXQuY3NzIiwibWFwcGluZ3MiOiI7Ozs7QUFBQSxpRUFBZSxjQUFjO0FBQzdCLElBQUksS0FBVSxFQUFFLEVBQXVCIiwic291cmNlcyI6WyIvVXNlcnMvbHVjdnMvRG93bmxvYWRzL2RpZ2l0YWwtYnVzaW5lc3MtY2FyZC9mcm9udGVuZC9ub2RlX21vZHVsZXMvLnBucG0vcHJldGVuZGFyZEAxLjMuOS9ub2RlX21vZHVsZXMvcHJldGVuZGFyZC9kaXN0L3dlYi92YXJpYWJsZS9wcmV0ZW5kYXJkdmFyaWFibGUtZHluYW1pYy1zdWJzZXQuY3NzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IFwiODBlMmRmZDIyZjZmXCJcbmlmIChtb2R1bGUuaG90KSB7IG1vZHVsZS5ob3QuYWNjZXB0KCkgfVxuIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6WzBdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/.pnpm/pretendard@1.3.9/node_modules/pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css\n");

/***/ })

};
;