This is a [Next.js](https://nextjs.org) project for Digital Business Card (DBC4Grad).

## Getting Started

First, run the development server:

```bash
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Deploy on Vercel

Way to deploy your Next.js app: [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme).

[Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying).
